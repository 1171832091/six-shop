<template>
    <div>
        登录
    </div>
</template>

<script>
    export default {
        name: "index"
    }
</script>

<style scoped>

</style>