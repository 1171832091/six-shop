<template>
    <div>
        详情
    </div>
</template>

<script>
    export default {
        methods:{

        },
        mounted(){
            console.log(1111111)
        }
    }
</script>

<style scoped>

</style>